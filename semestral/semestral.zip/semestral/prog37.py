def prog37():
    print('--------------------------------------')
    print('     Contar hasta un número dado      ')
    print('--------------------------------------\n ')

    con = int(input('ingrese un numero entero: '))
    cont = 0

    print()

    while cont < con :
        cont += 1
        print(cont)
