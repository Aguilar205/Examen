def prog47():
    print('---------------------------------')
    print('Sumar números pares del 1 al 100')
    print('---------------------------------\n')

    for i in range(2,101,2):
        print(i)
