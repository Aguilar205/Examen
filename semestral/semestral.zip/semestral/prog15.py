def prog15():
    print('=======================')
    print('   >>> TRIANGULO <<<')
    print('=======================\n')

    print('>ingrese cateto A:')
    CA = int(input('=>'))

    print()

    print('>ingrese cateto B:')
    CB = int(input('=>'))

    print()

    HIPO = CA**2 + CB**2

    print(f' hipotenusa de triangulo resctangulo es :{HIPO}')
