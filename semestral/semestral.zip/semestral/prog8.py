def prog8():
    print('-----------------------------------------------')
    print(' comvertidor de pies a metros y metros a pies')
    print('-----------------------------------------------\n')

    print('>> ingresa metros = pies:')
    p=float(input())
    pies=p*3.2808

    print('> pies:')
    print(pies)

    print()

    print('>> ingresa pies = metros:')
    m=float(input())
    metros=m*39.37

    print('> metros:')
    print(metros)
        
