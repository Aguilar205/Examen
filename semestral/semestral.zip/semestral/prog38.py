def prog38():
    print('---------------------------------')
    print('| Sumar números hasta un límite | ')
    print('--------------------------------- \n ')

    cont = 0

    while cont < 100 :
        cont += int(input('ingrese un numero: '))
        print('el numero va en ',cont)
        
    print()
              
    print(f'te pasaste por :{cont - 100}')            
        
          
    
