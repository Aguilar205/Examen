def prog50():
    print('________________________________________________')
    print('  Imprimir números impares, hasta un limite')
    print('________________________________________________\n')

    can = int(input("Ingrese un número límite: "))
    print()

    for i in range(1, can + 1, 2):
        print(i)
            
        
