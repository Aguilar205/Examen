def prog6():
    print('-------------------------')
    print('   VOLUMEN DE UN PRISMA')
    print('-------------------------\n')

    print('-LO ALTO ES:')
    A=float(input('->'))

    print('-LO ANCHO ES:')
    AN=float(input('->'))

    print('-LO LARGO ES:')
    L=float(input('->'))

    V=A*AN*L

    print('volumen:')
    print('->',V)
