def prog7():
    print('------------------------')
    print('  SOLUCION DE FORMULAS ')
    print('------------------------\n')

    print('valor de a:')
    a = int(input())
    print('valor de b:')
    b = int(input())
    print('valor de c:')
    c = int(input())

    print('c1=4a+3b\n c2=21a-18+8b-5\n c3=4a+3b+7\n c4=2a+3b-c^5\n c5=2a+3b-c^2\n')

    print('respuesta c1:')
    c1 = 4 * a + 3 * b
    print(c1)

    print('respuesta c2:')
    c2 = 21 * a - 18 + 8 * b - 5
    print(c2)

    print('respuesta c3:')
    c3 = 4 * a + 3 * b + 7
    print(c3)


    c4 = 2 * a + 3 * b - c ** 5
    print('respuesta c4:')
    print(c4)

    c5 = 2 * a + 3 * b - c ** 2
    print('respuesta c5:')
    print(c5)
        
