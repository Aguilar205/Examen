def prog4():
    print('-------------------------------')    
    print('   PERIMETRO DE UN RECTANGULO  ')
    print('-------------------------------\n')
    
    print('>>> LADO A:')
    A=float(input())

    print('>>> LADO B:')
    B=float(input())

    print('>>> LADO C:')
    C=float(input())

    print('>>> LADO D:')
    D=float(input())

    PERIMETRO=A+B+C+D

    print(f'>>>su perimetro es: >{PERIMETRO}<')
        
