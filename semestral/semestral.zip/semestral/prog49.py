def prog49():
    print('-----------------------------')
    print('Imprimir una serie de números')
    print('-----------------------------\n')

    lista = [10,9,8,7,6,5,4,3,2,1]

    for i in lista :
        print(i)
