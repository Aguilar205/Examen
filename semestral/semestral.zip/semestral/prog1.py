def prog1():
    print('💸💸 suma de variables 💸💸 \n \n')
    P1 =input('cantidad a: ')
    P2 =input('cantidad b: ')
    print()
    print('resultado:')
    print(float(P1)+float(P2))
