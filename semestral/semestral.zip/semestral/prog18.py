def prog18():
    print('****************************')
    print(' Determina si es adolecente ')
    print('****************************\n')

    edad = int(input('ingrese su edad:' ))

    print()

    if 13<=edad and edad <=19:
        print('!!!eres adolecente!!!')
        
    else:
        print(' -> no eres adolecente <- ')
    