def prog36():
    print("=============================")
    print('| sumar numero del 1 al 100 | ')
    print('=============================\n')

    con = 0
    while con < 100 :
        con += 1
        print(con)
