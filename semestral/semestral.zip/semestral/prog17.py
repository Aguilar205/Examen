def prog17():
    print('**************************')
    print('positivo , negativo o cero')
    print('**************************\n')

    numero = float(input('ingrese el valor: '))

    if numero >0:
        print('-> el numero es positivo \n')
        
    else:
        print('-> el numero es negativo \n')
        
      
    print()  
    print('"FIN"')
