def prog20():
    print('------------------------')
    print('  Determina se es vocal')
    print('------------------------')

    print()

    v = input('ingrese letra:')
    print()

    if v == 'A' or v == 'a':
        print('vocal')
        
    elif v == 'E' or v == 'e':
        print('vocal')
            
    elif v == 'I' or v == 'i' :
        print('vocal')
                
    elif v == 'O' or v == 'o':
        print('vocal')
                    
    elif v == 'U' or v == 'u' :
        print('vocal')
                        
    else:
        print('no es vocal')
