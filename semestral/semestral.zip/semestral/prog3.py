def prog3():
    print('AREA DE UN TRIANGULO RECTANGULO \n')
    print('>>>BASE:')
    B=float(input())
    print('>>>ALTURA:')
    A=float(input())

    AREA= (B*A)/2
    print()
    print(f' su area es: {AREA} ')
