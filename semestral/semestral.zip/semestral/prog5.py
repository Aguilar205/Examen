def prog5():
    print('-------------------------')
    print('   AREA DE UN TRAPECIO ')
    print('-------------------------\n')

    print('>>> base alta: ')
    B1=float(input('=>'))
    print()

    print('>>> base baja :')
    B2=float(input('=>'))
    print()

    print('>>> altura entre bases: ')
    ABB=float(input('=>'))

    print()
    A=((B1+B2)*ABB)/2

    print(f'su trapecio es:>{A}<')
        
