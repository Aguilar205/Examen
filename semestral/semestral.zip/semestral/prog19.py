def prog19():
    print('******************')
    print('  si es multiplo ')
    print('******************\n')

    m = int(input('ingrese número:'))
    print()

    if m % 5 == 0:
        print('-> es múltiplo de 5')
       
    else:
        print('-> no es múltiplo de 5')
